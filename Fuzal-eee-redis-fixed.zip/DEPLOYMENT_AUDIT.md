# Fuzal Deployment Audit

## Checked
- All 98 files in the supplied ZIP were inventoried.
- All Python source files under `backend/` pass Python syntax compilation.
- FastAPI test suite: **12/12 passed** when executed from `backend/`.
- Puzzle images exist in both `backend/images/` and `public/images/` (5 SVG files).
- Next.js routes and game source were statically inspected for deployment-sensitive localhost references.
- Vercel deployment metadata was added.
- Python/pytest cache artifacts were removed from the deployment package.

## Realtime deployment fix
The Next.js game now stores lobby state in Upstash Redis when
`UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN` are configured. Mutations
use a Redis lock per lobby, and the SSE endpoint polls shared state and emits
authoritative snapshots. This removes the previous process-local `Map` failure
where a lobby created on one Vercel instance could return 404 on another.

If the Redis variables are absent, the repository intentionally falls back to
in-memory storage for local development/tests only.

## Vercel target
The ZIP root is the Vercel target. `vercel.json` configures:
- Framework: Next.js
- Build: `npm run build`
- Install: `npm install`

Set `NEXT_PUBLIC_SITE_URL` to the final HTTPS Vercel/custom domain if you want a canonical QR origin; otherwise the QR uses the current browser origin.
