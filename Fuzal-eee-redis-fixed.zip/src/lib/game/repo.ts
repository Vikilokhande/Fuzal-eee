/**
 * Lobby repository.
 *
 * Production uses Upstash Redis so lobby state is shared across all Vercel
 * function instances. Local development/tests fall back to the in-memory
 * repository when the Redis environment variables are not present.
 */
import { randomUUID } from "node:crypto";
import { Redis } from "@upstash/redis";
import type { Lobby, Player } from "./types";

export interface LobbyRepository {
  put(lobby: Lobby): Promise<Lobby>;
  getByCode(code: string): Promise<Lobby | null>;
  deleteByCode(code: string): Promise<void>;
  size(): Promise<number>;
}

type StoredLobby = Omit<
  Lobby,
  "lockChain" | "timerInterval" | "endTimeout" | "disconnectTimers"
>;

const REDIS_LOBBY_TTL_SECONDS = 60 * 60 * 6;
const REDIS_PREFIX = "fuzal:lobby:";
const REDIS_LOCK_PREFIX = "fuzal:lock:";

const redisUrl =
  process.env.UPSTASH_REDIS_REST_URL ?? process.env.KV_REST_API_URL;
const redisToken =
  process.env.UPSTASH_REDIS_REST_TOKEN ?? process.env.KV_REST_API_TOKEN;
const redisEnabled = Boolean(redisUrl && redisToken);

const redis = redisEnabled
  ? new Redis({ url: redisUrl!, token: redisToken! })
  : null;

function lobbyKey(code: string) {
  return `${REDIS_PREFIX}${code}`;
}

function lockKey(code: string) {
  return `${REDIS_LOCK_PREFIX}${code}`;
}

function serializeLobby(lobby: Lobby): StoredLobby {
  const {
    lockChain: _lockChain,
    timerInterval: _timerInterval,
    endTimeout: _endTimeout,
    disconnectTimers: _disconnectTimers,
    ...stored
  } = lobby;
  return stored;
}

function hydrateLobby(stored: StoredLobby): Lobby {
  return {
    ...stored,
    lockChain: Promise.resolve(),
    timerInterval: null,
    endTimeout: null,
    disconnectTimers: {},
  };
}

function decodeStored(value: StoredLobby | string | null): StoredLobby | null {
  if (!value) return null;
  if (typeof value === "string") {
    try {
      return JSON.parse(value) as StoredLobby;
    } catch {
      return null;
    }
  }
  return value;
}

class InMemoryLobbyRepository implements LobbyRepository {
  private lobbies = new Map<string, Lobby>();

  async put(lobby: Lobby): Promise<Lobby> {
    this.lobbies.set(lobby.code, lobby);
    return lobby;
  }

  async getByCode(code: string): Promise<Lobby | null> {
    return this.lobbies.get(code) ?? null;
  }

  async deleteByCode(code: string): Promise<void> {
    this.lobbies.delete(code);
  }

  async size(): Promise<number> {
    return this.lobbies.size;
  }
}

class RedisLobbyRepository implements LobbyRepository {
  constructor(private readonly client: Redis) {}

  async put(lobby: Lobby): Promise<Lobby> {
    await this.client.set(lobbyKey(lobby.code), serializeLobby(lobby), {
      ex: REDIS_LOBBY_TTL_SECONDS,
    });
    return lobby;
  }

  async getByCode(code: string): Promise<Lobby | null> {
    const stored = decodeStored(
      await this.client.get<StoredLobby | string>(lobbyKey(code)),
    );
    return stored ? hydrateLobby(stored) : null;
  }

  async deleteByCode(code: string): Promise<void> {
    await this.client.del(lobbyKey(code));
  }

  async size(): Promise<number> {
    let cursor = 0;
    let total = 0;
    do {
      const result = await this.client.scan(cursor, {
        match: `${REDIS_PREFIX}*`,
        count: 100,
      });
      cursor = Number(result[0]);
      total += result[1].length;
    } while (cursor !== 0);
    return total;
  }
}

const globalForRepo = globalThis as typeof globalThis & {
  __fuzalRepo?: LobbyRepository;
};

export const lobbyRepo: LobbyRepository =
  globalForRepo.__fuzalRepo ??
  (redis ? new RedisLobbyRepository(redis) : new InMemoryLobbyRepository());
if (process.env.NODE_ENV !== "production") {
  globalForRepo.__fuzalRepo = lobbyRepo;
}

const RELEASE_LOCK_SCRIPT = `
  if redis.call("get", KEYS[1]) == ARGV[1] then
    return redis.call("del", KEYS[1])
  end
  return 0
`;

async function withDistributedLock<T>(lobby: Lobby, fn: () => Promise<T> | T) {
  if (!redis) {
    const run = lobby.lockChain.then(() => fn());
    lobby.lockChain = run.then(
      () => undefined,
      () => undefined,
    );
    return run;
  }

  const token = randomUUID();
  const key = lockKey(lobby.code);
  const timeoutAt = Date.now() + 10_000;

  while (Date.now() < timeoutAt) {
    const acquired = await redis.set(key, token, { nx: true, ex: 15 });
    if (acquired === "OK") {
      try {
        // The caller may have fetched the lobby on another Vercel instance
        // before acquiring the lock. Refresh it so mutations always start
        // from the latest shared state.
        const fresh = await lobbyRepo.getByCode(lobby.code);
        if (!fresh) return await fn();

        Object.assign(lobby, fresh);
        return await fn();
      } finally {
        await redis.eval(RELEASE_LOCK_SCRIPT, [key], [token]);
      }
    }
    await new Promise((resolve) => setTimeout(resolve, 50));
  }

  throw new Error("Could not acquire lobby lock. Please retry.");
}

/**
 * Serialize every mutating operation on a single lobby.
 * In production this is a short-lived Redis lock; locally it is a promise
 * chain. The lock is acquired before refreshing the lobby from shared state.
 */
export function withLobbyLock<T>(
  lobby: Lobby,
  fn: () => Promise<T> | T,
): Promise<T> {
  return withDistributedLock(lobby, fn);
}

export function findPlayer(lobby: Lobby, playerId: string): Player | undefined {
  return lobby.players.find((p) => p.id === playerId);
}

export function usingSharedLobbyStore(): boolean {
  return Boolean(redis);
}
