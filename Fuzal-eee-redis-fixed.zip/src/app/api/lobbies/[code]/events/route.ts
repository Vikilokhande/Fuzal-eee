import { lobbyService } from "@/lib/game/service";
import { LOBBY_CODE_RE, PLAYER_ID_RE, EventType } from "@/lib/game/types";
import { errorResponse } from "@/lib/game/http";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * Cross-instance realtime channel.
 *
 * Vercel can move successive requests to different instances, so an
 * in-process subscriber map cannot be the source of truth. This endpoint
 * keeps the SSE connection local to the current function but polls the shared
 * Redis-backed lobby state and emits a fresh authoritative SNAPSHOT whenever
 * that state changes. The browser already calculates the countdown from
 * endsAt, so no per-second server timer is required.
 */
export async function GET(
  req: Request,
  ctx: { params: Promise<{ code: string }> },
) {
  const { code } = await ctx.params;
  if (!LOBBY_CODE_RE.test(code)) {
    return Response.json(
      { error: "BAD_REQUEST", message: "Invalid game code." },
      { status: 400 },
    );
  }

  const url = new URL(req.url);
  const kind = url.searchParams.get("kind") === "host" ? "host" : "player";
  const hostToken = url.searchParams.get("t") ?? "";
  const playerId = url.searchParams.get("p") ?? "";
  const playerToken = url.searchParams.get("t") ?? "";

  if (kind === "host" ? hostToken.length < 10 : !PLAYER_ID_RE.test(playerId)) {
    return Response.json(
      { error: "FORBIDDEN", message: "Invalid connection parameters." },
      { status: 403 },
    );
  }

  let connected: Awaited<ReturnType<typeof lobbyService.handleConnect>>;
  try {
    connected = await lobbyService.handleConnect(code, {
      hostToken: kind === "host" ? hostToken : undefined,
      playerId: kind === "player" ? playerId : undefined,
      playerToken: kind === "player" ? playerToken : undefined,
    });
  } catch (e) {
    return errorResponse(e);
  }

  const encoder = new TextEncoder();
  const subscribeId = kind === "host" ? `host:${code}` : playerId!;
  let closed = false;

  // Keep a compact representation for change detection. serverNow and the
  // derived countdown are intentionally excluded so an idle lobby does not
  // generate a new frame every second.
  const stateFingerprint = (snapshot: { payload: Record<string, unknown> }) => {
    const payload = snapshot.payload;
    return JSON.stringify({
      ...payload,
      serverNow: 0,
      memory: payload.memory
        ? { ...payload.memory, remaining: 0 }
        : null,
    });
  };

  const stream = new ReadableStream({
    async start(controller) {
      const sendFrame = (event: unknown) => {
        if (closed) return;
        try {
          controller.enqueue(
            encoder.encode(`data: ${JSON.stringify(event)}\n\n`),
          );
        } catch {
          closed = true;
        }
      };

      try {
        let lobby = await lobbyService.syncPhase(code);
        let currentPlayer =
          kind === "player"
            ? lobby.players.find((p) => p.id === playerId)
            : undefined;
        let snapshot = lobbyService.buildSnapshot(lobby, kind, currentPlayer);
        let fingerprint = stateFingerprint(snapshot);
        sendFrame(snapshot);

        const poll = setInterval(async () => {
          if (closed) return;
          try {
            lobby = await lobbyService.syncPhase(code);
            currentPlayer =
              kind === "player"
                ? lobby.players.find((p) => p.id === playerId)
                : undefined;
            snapshot = lobbyService.buildSnapshot(lobby, kind, currentPlayer);
            const nextFingerprint = stateFingerprint(snapshot);
            if (nextFingerprint !== fingerprint) {
              fingerprint = nextFingerprint;
              sendFrame(snapshot);
            }
          } catch (e) {
            // A deleted/expired lobby should close the stream cleanly. Other
            // transient errors are retried on the next poll.
            if ((e as { httpStatus?: number })?.httpStatus === 404) {
              clearInterval(poll);
              sendFrame({
                type: EventType.ERROR,
                at: Date.now(),
                payload: { message: "Lobby not found." },
              });
              closed = true;
              try {
                controller.close();
              } catch {
                /* noop */
              }
            }
          }
        }, 750);

        const heartbeat = setInterval(() => {
          if (closed) return;
          try {
            controller.enqueue(encoder.encode(": ping\n\n"));
          } catch {
            closed = true;
          }
        }, 20_000);

        const cleanup = () => {
          if (closed) return;
          closed = true;
          clearInterval(poll);
          clearInterval(heartbeat);
          if (kind === "player" && playerId) {
            void lobbyService.handleDisconnect(code, playerId);
          }
          try {
            controller.close();
          } catch {
            /* noop */
          }
        };

        req.signal.addEventListener("abort", cleanup);
      } catch (e) {
        closed = true;
        try {
          controller.error(e);
        } catch {
          /* noop */
        }
      }
    },
    cancel() {
      closed = true;
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
